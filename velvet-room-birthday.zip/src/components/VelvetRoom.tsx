import { AnimatePresence, motion } from 'motion/react';
import { Volume2, VolumeX } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { Particles } from './Particles';
import { Fog } from './Fog';

// A placeholder for the background audio. 
// To use actual Persona music, replace this empty string with the path to your local MP3 file 
// (e.g., "/aria-of-the-soul.mp3") in the public folder.
const AUDIO_SRC = "";

// A placeholder for the default background image. 
// Replace with your default image path (e.g., "/velvet-bg.jpg"). Leave empty for just the gradient.
const DEFAULT_BG_IMAGE = "";

type MessageLine = {
  text: string;
  bgImage?: string;
};

const messageLines: MessageLine[] = [
  { text: "Bienvenido a la VELVET ROOM. Tu destino te ha traído hasta este nuevo año de vida." },
  { text: "Este lugar existe entre el sueño y la realidad, la mente y la materia... y hoy la Habitación Terciopelo abre sus puertas para honrar tu progreso, tu viaje y las decisiones que te han traído hasta aquí." },
  { text: "A lo largo del tiempo, has forjado vínculos inquebrantables, superado adversidades y descubierto nuevas facetas de tu propio corazón a través de la saga de tu propia existencia:" },
  { text: "Has aprendido a buscar la Verdad entre los rumores, transformando tus pensamientos en la fuerza que moldea el mundo a tu alrededor." },
  { text: "Miraste de frente al Memento Mori para encender tu propia determinación (Burn My Dread), enfrentando la hora medianoche con un valor que solo tú posees." },
  { text: "Despejaste la niebla de la incertidumbre aceptando cada parte de tu ser, demostrando que comprender tu sombra es el paso definitivo para alcanzar la autenticidad." },
  { text: "Rompiste las cadenas del destino como un verdadero rebelde, robándote el corazón de quienes te rodean con la convicción de tu libertad." },
  { text: "La vida es un viaje compuesto de innumerables elecciones. Aunque las antiguas leyendas hablen de profecías entre la luz y la sombra, la verdad es que ninguna profecía está tallada en piedra." },
  { text: "Algunas decisiones son sencillas; otras exigen un poder que siempre ha residido en ti. Has aceptado la responsabilidad de tu camino y tus Vínculos Sociales continúan otorgándote la energía para despertar a tu verdadero potencial." },
  { text: "Tú eres yo, y yo soy tú... Los vínculos que has forjado se han convertido en la fuerza que guía tu destino. Que estas alianzas rompan cualquier cadena y se conviertan en las alas que te lleven hacia tu verdadero potencial.", bgImage: "" }, // You can add specific images per line here
  { text: "Nunca lo olvides: eres el autor de tu propio destino, nada está escrito y el poder de cambiar el mundo está en tus manos. Las cartas están a tu favor." },
  { text: "¡Feliz Cumpleaños!" },
  { text: "Hasta que nos volvamos a encontrar en este lugar donde el destino se forja..." }
];

export function VelvetRoom() {
  const [hasEntered, setHasEntered] = useState(false);
  const [volume, setVolume] = useState(0.5);
  const [isMuted, setIsMuted] = useState(false);
  const [currentLineIndex, setCurrentLineIndex] = useState(0);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume;
    }
  }, [volume, isMuted]);

  useEffect(() => {
    if (!hasEntered) return;
    
    if (currentLineIndex < messageLines.length - 1) {
      // Calculate a comfortable reading time, approx ~60ms per character with a 3.5s minimum
      const readTime = Math.max(3500, messageLines[currentLineIndex].text.length * 60);
      const timer = setTimeout(() => {
        setCurrentLineIndex(prev => prev + 1);
      }, readTime);
      return () => clearTimeout(timer);
    }
  }, [hasEntered, currentLineIndex]);

  const handleEnter = () => {
    setHasEntered(true);
    if (audioRef.current && AUDIO_SRC) {
      audioRef.current.play().catch(e => console.error("Audio playback failed:", e));
    }
  };

  const toggleMute = () => setIsMuted(!isMuted);
  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setVolume(parseFloat(e.target.value));
    if (isMuted && parseFloat(e.target.value) > 0) {
      setIsMuted(false);
    }
  };

  return (
    <div className="relative w-full h-screen font-sans text-white overflow-hidden bg-velvet-dark">
      {/* Background audio element */}
      {AUDIO_SRC && <audio ref={audioRef} src={AUDIO_SRC} loop preload="auto" />}

      <AnimatePresence mode="wait">
        {!hasEntered ? (
          <motion.div 
            key="welcome"
            className="absolute inset-0 flex flex-col items-center justify-center z-50 bg-velvet-dark"
            exit={{ opacity: 0, transition: { duration: 1.5, ease: "easeInOut" } }}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 2, ease: "easeOut" }}
              className="flex flex-col items-center gap-10"
            >
              <h1 className="text-4xl md:text-5xl font-serif text-velvet-gold-light text-glow-gold tracking-widest text-center px-6">
                Bienvenido a la<br className="md:hidden" /> Habitación Terciopelo
              </h1>
              
              <button 
                onClick={handleEnter}
                className="group relative px-8 py-3 overflow-hidden rounded-sm border border-velvet-gold/60 bg-transparent transition-all duration-500 hover:border-velvet-gold hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] focus:outline-none"
              >
                <div className="absolute inset-0 bg-velvet-gold/5 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left"></div>
                <span className="relative font-serif text-xl tracking-wider text-velvet-gold-light group-hover:text-white transition-colors duration-300">
                  Firmar el Contrato
                </span>
              </button>
            </motion.div>
          </motion.div>
        ) : (
          <motion.div 
            key="main-room"
            className="absolute inset-0 bg-velvet-gradient flex items-center justify-center overflow-hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 2 }}
          >
            {/* Dynamic Background Image Layer */}
            <AnimatePresence mode="popLayout">
              {(messageLines[currentLineIndex].bgImage || DEFAULT_BG_IMAGE) && (
                <motion.div
                  key={messageLines[currentLineIndex].bgImage || DEFAULT_BG_IMAGE}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 0.15 }} // Keep it subtle to not overpower the Velvet Room vibe
                  exit={{ opacity: 0 }}
                  transition={{ duration: 2, ease: "easeInOut" }}
                  className="absolute inset-0 bg-cover bg-center bg-no-repeat pointer-events-none mix-blend-luminosity"
                  style={{ backgroundImage: `url(${messageLines[currentLineIndex].bgImage || DEFAULT_BG_IMAGE})` }}
                />
              )}
            </AnimatePresence>

            <Fog />
            <Particles />
            
            {/* Main Content Glass Panel */}
            <motion.div 
              className="relative z-10 w-full max-w-4xl mx-4 py-12 px-6 md:px-12 glass-panel rounded-sm flex flex-col items-center justify-center min-h-[45vh] md:min-h-[50vh] cursor-pointer"
              initial={{ scale: 0.8, opacity: 0, rotateX: 15, y: 50, filter: 'blur(10px)' }}
              animate={{ scale: 1, opacity: 1, rotateX: 0, y: 0, filter: 'blur(0px)' }}
              transition={{ duration: 1.8, delay: 0.2, type: "spring", bounce: 0.2 }}
              style={{ perspective: 1000 }}
              onClick={() => {
                if (currentLineIndex < messageLines.length - 1) {
                  setCurrentLineIndex(prev => prev + 1);
                }
              }}
            >
              {/* Animated Glowing Borders */}
              <motion.div className="absolute top-0 left-1/2 h-[2px] bg-velvet-gold-light shadow-[0_0_15px_2px_rgba(212,175,55,1)]" initial={{ width: 0, x: "-50%" }} animate={{ width: "100%" }} transition={{ duration: 1.5, ease: "easeInOut", delay: 1 }} />
              <motion.div className="absolute bottom-0 left-1/2 h-[2px] bg-velvet-gold-light shadow-[0_0_15px_2px_rgba(212,175,55,1)]" initial={{ width: 0, x: "-50%" }} animate={{ width: "100%" }} transition={{ duration: 1.5, ease: "easeInOut", delay: 1 }} />
              <motion.div className="absolute top-1/2 left-0 w-[2px] bg-velvet-gold-light shadow-[0_0_15px_2px_rgba(212,175,55,1)]" initial={{ height: 0, y: "-50%" }} animate={{ height: "100%" }} transition={{ duration: 1.5, ease: "easeInOut", delay: 2.2 }} />
              <motion.div className="absolute top-1/2 right-0 w-[2px] bg-velvet-gold-light shadow-[0_0_15px_2px_rgba(212,175,55,1)]" initial={{ height: 0, y: "-50%" }} animate={{ height: "100%" }} transition={{ duration: 1.5, ease: "easeInOut", delay: 2.2 }} />

              {/* Decorative Corner Ornaments */}
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 3.5, duration: 1.5 }}>
                <div className="absolute top-3 left-3 w-4 h-4 border-t-2 border-l-2 border-velvet-gold/80 shadow-[0_0_10px_rgba(212,175,55,0.8)]"></div>
                <div className="absolute top-3 right-3 w-4 h-4 border-t-2 border-r-2 border-velvet-gold/80 shadow-[0_0_10px_rgba(212,175,55,0.8)]"></div>
                <div className="absolute bottom-3 left-3 w-4 h-4 border-b-2 border-l-2 border-velvet-gold/80 shadow-[0_0_10px_rgba(212,175,55,0.8)]"></div>
                <div className="absolute bottom-3 right-3 w-4 h-4 border-b-2 border-r-2 border-velvet-gold/80 shadow-[0_0_10px_rgba(212,175,55,0.8)]"></div>
              </motion.div>

              {/* Text Display Sequence */}
              <div className="w-full relative flex items-center justify-center">
                <AnimatePresence mode="wait">
                  <motion.p
                    key={currentLineIndex}
                    initial={{ opacity: 0, y: 15, filter: 'blur(8px)' }}
                    animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                    exit={{ opacity: 0, y: -15, filter: 'blur(8px)' }}
                    transition={{ duration: 1.5, ease: "easeInOut" }}
                    className={`font-serif leading-relaxed tracking-wide text-center px-4 ${
                      messageLines[currentLineIndex].text.includes("Feliz Cumpleaños")
                        ? "text-4xl md:text-6xl text-velvet-gold-light text-glow-gold font-bold" 
                        : "text-xl md:text-3xl text-blue-50 text-glow-blue"
                    }`}
                  >
                    {messageLines[currentLineIndex].text}
                  </motion.p>
                </AnimatePresence>
              </div>
              
              {/* Indicator for clicking/auto-advance */}
              {currentLineIndex < messageLines.length - 1 && (
                <motion.div 
                  className="absolute bottom-6 right-8 text-velvet-gold-light text-sm font-sans tracking-widest text-glow-gold"
                  animate={{ opacity: [0, 1, 0] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                >
                  ▼
                </motion.div>
              )}
            </motion.div>

            {/* Audio Controls */}
            {AUDIO_SRC && (
              <motion.div 
                className="absolute bottom-6 right-6 z-20 flex items-center gap-4 bg-velvet-dark/50 backdrop-blur-sm p-3 rounded-md border border-white/10"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 2, duration: 1 }}
              >
                <button 
                  onClick={toggleMute}
                  className="text-velvet-gold-light hover:text-white transition-colors focus:outline-none"
                  aria-label={isMuted ? "Unmute" : "Mute"}
                >
                  {isMuted || volume === 0 ? <VolumeX size={20} /> : <Volume2 size={20} />}
                </button>
                <input 
                  type="range" 
                  min="0" 
                  max="1" 
                  step="0.01" 
                  value={isMuted ? 0 : volume}
                  onChange={handleVolumeChange}
                  className="w-24 h-1 bg-white/20 rounded-lg appearance-none cursor-pointer accent-velvet-gold-light"
                  aria-label="Volume"
                />
              </motion.div>
            )}

          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
